import json, sys
ip = sys.argv[1] if len(sys.argv) > 1 else ''
print(json.dumps({'findings': []}))
